Project URL: http://d234lbrfsm6hda.cloudfront.net/index.html

- Changed the background in index.html
- Changed the title